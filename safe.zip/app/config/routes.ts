export const Routes = {
  public: {
    home: '/',
    safe: '/safe'
  },
};
